"""Soak helper for the CivicCast staff API. Token comes from the CIVICCAST_STAFF_TOKEN environment variable only.

Usage (python SOAK-api.py <command> ...):
  status                                  channel state/health summary + assets + schedule counts
  upload <path> <asset_id> <title>        multipart upload (POST /api/staff/assets/upload) and print the response
  assets                                  list assets (id, title, state)
  slots <channel> <start_iso> <hours> <minutes> <asset_id,asset_id,...>   create back-to-back 'once' program slots
  materialize                             POST /api/staff/programlog/materialize
  log <channel>                           list program-log entries (occurrence_id, schedule_item_id, status, start)
  commit-all <channel>                    commit every scheduled occurrence to air (prepare-commit then commit)
  preset <channel> <profile_id> <udp_uri> [keep_existing_sinks 0|1]   apply a headend profile
  cmd <channel> <start|stop|reload|drain> queue an egress command
  raw <GET|POST|PUT> <path> [json]        arbitrary call
"""
import json, os, sys, time, datetime, mimetypes, uuid, urllib.request, urllib.error

BASE = "http://127.0.0.1:8000"
TOKEN = os.environ.get("CIVICCAST_STAFF_TOKEN", "")
if not TOKEN:
    print("CIVICCAST_STAFF_TOKEN not set", file=sys.stderr); sys.exit(2)

def call(method, path, body=None, raw_body=None, content_type=None, timeout=600):
    data = None; headers = {"Authorization": "Bearer " + TOKEN}
    if body is not None:
        data = json.dumps(body).encode(); headers["Content-Type"] = "application/json"
    if raw_body is not None:
        data = raw_body; headers["Content-Type"] = content_type
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            t = r.read().decode("utf-8", "replace")
            try: return r.status, json.loads(t)
            except Exception: return r.status, t
    except urllib.error.HTTPError as e:
        t = e.read().decode("utf-8", "replace")
        try: return e.code, json.loads(t)
        except Exception: return e.code, t

def upload(path, asset_id, title):
    boundary = "----soak" + uuid.uuid4().hex
    fname = os.path.basename(path)
    ctype = mimetypes.guess_type(fname)[0] or "video/mp4"
    parts = []
    for k, v in (("asset_id", asset_id), ("title", title), ("description", "Overnight soak clip (from the beta.5 kit samples)")):
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
    with open(path, "rb") as f:
        filedata = f.read()
    head = f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{fname}\"\r\nContent-Type: {ctype}\r\n\r\n".encode()
    body = b"".join(parts) + head + filedata + f"\r\n--{boundary}--\r\n".encode()
    t0 = time.time()
    status, resp = call("POST", "/api/staff/assets/upload", raw_body=body, content_type=f"multipart/form-data; boundary={boundary}", timeout=1800)
    print(f"upload {fname} ({len(filedata)/1048576:.1f} MB) -> {status} in {time.time()-t0:.0f}s")
    print(json.dumps(resp, indent=1)[:1200])

def slots(channel, start_iso, hours, minutes, assets):
    start = datetime.datetime.fromisoformat(start_iso)
    if start.tzinfo is None:
        start = start.astimezone()
    n = int(hours * 60 / minutes)
    created = 0; errors = 0
    for i in range(n):
        asset = assets[i % len(assets)]
        at = start + datetime.timedelta(minutes=minutes * i)
        body = {"channel_id": channel, "asset_id": asset, "recurrence": "once", "first_start_at": at.isoformat(), "duration_seconds": minutes * 60, "title_override": f"Soak {channel} #{i+1:03d} {asset[:18]}"}
        status, resp = call("POST", "/api/staff/programlog/slots", body)
        if status in (200, 201): created += 1
        else:
            errors += 1
            if errors <= 3: print("slot error", status, json.dumps(resp)[:300])
    print(f"{channel}: created {created}/{n} slots from {start.isoformat()} every {minutes} min; errors {errors}")

def log(channel, quiet=False):
    status, entries = call("GET", f"/api/staff/programlog/channels/{channel}/log")
    if status != 200 or not isinstance(entries, list):
        print("log error", status, json.dumps(entries)[:300]); return []
    if not quiet:
        for e in entries[:400]:
            print(json.dumps({k: e.get(k) for k in ("occurrence_id", "schedule_item_id", "status", "state", "start_at", "scheduled_at", "title", "asset_id") if k in e}))
        print(f"{len(entries)} entries")
    return entries

def commit_all(channel):
    entries = log(channel, quiet=True)
    done = 0; skipped = 0; failed = 0
    for e in entries:
        occ = e.get("occurrence_id"); sid = e.get("schedule_item_id")
        st = (e.get("status") or e.get("state") or "").lower()
        if not occ or not sid or st not in ("scheduled", "pending", "materialized", ""):
            skipped += 1; continue
        body = {"channel_id": channel, "occurrence_id": occ, "schedule_item_id": sid}
        ps, pr = call("POST", "/api/staff/playout/prepare-commit", body)
        cs, cr = call("POST", "/api/staff/playout/commit", dict(body, operator_notes="overnight soak auto-commit"))
        if cs in (200, 201): done += 1
        else:
            failed += 1
            if failed <= 3: print("commit error", cs, json.dumps(cr)[:400], "| prepare", ps, json.dumps(pr)[:200])
    print(f"{channel}: committed {done}, skipped {skipped}, failed {failed}")

def status():
    for ch in ("public", "government", "education"):
        s, d = call("GET", f"/api/staff/egress/channels/{ch}")
        st = d.get("state") if isinstance(d, dict) else None
        cfg = d.get("config") if isinstance(d, dict) else None
        sinks = [x.get("kind") + ":" + x.get("uri", "")[:40] for x in (cfg or {}).get("sinks", [])] if cfg else None
        print(f"{ch}: http {s} state={json.dumps(st)[:300]} sinks={sinks} enabled={(cfg or {}).get('enabled')}")
    s, a = call("GET", "/api/staff/assets")
    items = a if isinstance(a, list) else a.get("items", []) if isinstance(a, dict) else []
    print("assets:", [(x.get("asset_id"), x.get("state") or x.get("status")) for x in items])
    s, sch = call("GET", "/api/staff/schedule")
    sitems = sch if isinstance(sch, list) else sch.get("items", []) if isinstance(sch, dict) else []
    from collections import Counter
    print("schedule items:", len(sitems), Counter((x.get("channel_id"), x.get("state")) for x in sitems))
    s, p = call("GET", "/api/staff/station/profile")
    print("live_captions_enabled:", p.get("live_captions_enabled") if isinstance(p, dict) else p)

cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
if cmd == "status": status()
elif cmd == "upload": upload(sys.argv[2], sys.argv[3], sys.argv[4])
elif cmd == "assets":
    s, a = call("GET", "/api/staff/assets"); items = a if isinstance(a, list) else a.get("items", [])
    for x in items: print(x.get("asset_id"), "|", x.get("title"), "|", x.get("state") or x.get("status"), "|", x.get("duration_seconds"))
elif cmd == "slots": slots(sys.argv[2], sys.argv[3], float(sys.argv[4]), int(sys.argv[5]), sys.argv[6].split(","))
elif cmd == "materialize": print(call("POST", "/api/staff/programlog/materialize", {}))
elif cmd == "log": log(sys.argv[2])
elif cmd == "commit-all": commit_all(sys.argv[2])
elif cmd == "preset":
    keep = bool(int(sys.argv[5])) if len(sys.argv) > 5 else True
    print(json.dumps(call("POST", f"/api/staff/egress/channels/{sys.argv[2]}/config/headend-profile", {"profile_id": sys.argv[3], "destination_uri": sys.argv[4], "keep_existing_sinks": keep}), indent=1)[:2500])
elif cmd == "cmd": print(call("POST", f"/api/staff/egress/channels/{sys.argv[2]}/commands", {"action": sys.argv[3]}))
elif cmd == "raw":
    body = json.loads(sys.argv[4]) if len(sys.argv) > 4 else None
    s, r = call(sys.argv[2], sys.argv[3], body); print(s); print(json.dumps(r, indent=1)[:4000] if not isinstance(r, str) else r[:4000])
else: print(__doc__)

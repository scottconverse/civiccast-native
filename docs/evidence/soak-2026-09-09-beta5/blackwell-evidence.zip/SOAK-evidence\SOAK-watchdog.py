r"""Operator watchdog for the overnight soak.

Does exactly what a human operator would do: if a channel is STOPPED for more than
GRACE seconds, press Start again, and write it down. It changes NO station setting and
issues no other command. Its purpose is to keep the 8-hour soak producing data after the
S-08 silent-death bug takes a channel off air, since the daemon never recovers on its own.

Every death and every intervention is logged with timestamps to SOAK-interventions.log, so
the raw fault record is preserved; the GRACE delay keeps the off-air alert latency measurable.

Token comes from CIVICCAST_STAFF_TOKEN in the environment only, never from a file.
Exits when C:\Users\scott\Desktop\SOAK-STOP exists or at the deadline.
"""
import json, os, time, datetime, urllib.request, urllib.error

BASE = "http://127.0.0.1:8000"
TOKEN = os.environ["CIVICCAST_STAFF_TOKEN"]
CHANNELS = ("public", "government", "education")
GRACE = 120.0          # seconds a channel may sit STOPPED before the watchdog acts
POLL = 10.0
LOG = r"C:\Users\scott\Desktop\SOAK-interventions.log"
STOP = r"C:\Users\scott\Desktop\SOAK-STOP"
DEADLINE = time.time() + 7.2 * 3600

def now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def say(line):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"{now()} {line}\n")

def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Authorization": "Bearer " + TOKEN}
    if data:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return 0, str(e)

stopped_since = {c: None for c in CHANNELS}
count = {c: 0 for c in CHANNELS}
say(f"watchdog started (grace {GRACE:.0f}s, poll {POLL:.0f}s); restarts a channel only after it "
    f"has been STOPPED that long, and logs every one")

while time.time() < DEADLINE and not os.path.exists(STOP):
    for ch in CHANNELS:
        st, body = call("GET", f"/api/staff/egress/channels/{ch}/state")
        state = (body or {}).get("state") if isinstance(body, dict) else None
        if st != 200 or state is None:
            continue
        if state == "STOPPED":
            if stopped_since[ch] is None:
                stopped_since[ch] = time.time()
                say(f"[{ch}] observed STOPPED (no operator command was issued; this is the S-08 "
                    f"silent death). Waiting {GRACE:.0f}s before restarting.")
            elif time.time() - stopped_since[ch] >= GRACE:
                dark = time.time() - stopped_since[ch]
                s, r = call("POST", f"/api/staff/egress/channels/{ch}/commands", {"action": "start"})
                count[ch] += 1
                say(f"[{ch}] OPERATOR RESTART #{count[ch]} issued after {dark:.0f}s dark -> http {s}")
                stopped_since[ch] = None
                time.sleep(5)
        else:
            if stopped_since[ch] is not None:
                say(f"[{ch}] back to {state} on its own before the watchdog acted")
            stopped_since[ch] = None
    time.sleep(POLL)

say(f"watchdog exiting; restarts issued: " + ", ".join(f"{c}={count[c]}" for c in CHANNELS))

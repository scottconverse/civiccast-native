"""CivicCast beta.5 overnight soak sampler (NvideaBlackwell, 2026-09-09).

Runs detached. Reads the staff token from the environment only (never from or to a file).
Writes on the Desktop: SOAK-samples.csv (one row per channel every 5 min), SOAK-events.log
(timestamped events), SOAK-raw.jsonl (raw API payloads per sample), SOAK-sampler.log (errors),
SOAK-udp.log (per-minute UDP feed stats per channel).
Stops when SOAK-STOP exists on the Desktop or after SOAK_HOURS elapsed.
"""
import csv, json, os, socket, subprocess, sys, threading, time, datetime, urllib.request, urllib.error

BASE = "http://127.0.0.1:8000"
TOKEN = os.environ.get("CIVICCAST_STAFF_TOKEN", "")
DESK = r"C:\Users\scott\Desktop"
CSV_PATH = os.path.join(DESK, "SOAK-samples.csv")
EVENTS_PATH = os.path.join(DESK, "SOAK-events.log")
RAW_PATH = os.path.join(DESK, "SOAK-raw.jsonl")
LOG_PATH = os.path.join(DESK, "SOAK-sampler.log")
UDP_LOG = os.path.join(DESK, "SOAK-udp.log")
STOP_PATH = os.path.join(DESK, "SOAK-STOP")
CHANNELS = {"public": 5000, "government": 5001, "education": 5002}
SAMPLE_EVERY = 300
STATE_EVERY = 5
SOAK_HOURS = float(os.environ.get("SOAK_HOURS", "8.3"))
FREEZE_SECONDS = 5.0
ON_AIR_STATES = ("ON_AIR",)

def now():
    return datetime.datetime.now().astimezone()

def ts():
    return now().strftime("%Y-%m-%d %H:%M:%S")

def log(msg):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"{ts()} {msg}\n")

def event(msg):
    line = f"{ts()} {msg}"
    with open(EVENTS_PATH, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)

def api(path, auth=True, timeout=15):
    req = urllib.request.Request(BASE + path)
    if auth and TOKEN:
        req.add_header("Authorization", "Bearer " + TOKEN)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
            try:
                return r.status, json.loads(body, strict=False)
            except Exception:
                return r.status, body
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8", "replace"), strict=False)
        except Exception:
            return e.code, None
    except Exception as e:
        return 0, str(e)

# ---------------------------------------------------------------- processes
def processes():
    ps = "Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId,WorkingSetSize,CommandLine,ExecutablePath | ConvertTo-Json -Compress"
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=90).stdout.strip()
        data = json.loads(out) if out else []
        if isinstance(data, dict):
            data = [data]
    except Exception as e:
        log(f"process scan failed: {e}")
        return []
    by_pid = {p.get("ProcessId"): p for p in data}
    roots = set()
    for p in data:
        name = (p.get("Name") or "").lower()
        text = ((p.get("CommandLine") or "") + " " + (p.get("ExecutablePath") or "")).lower()
        if name == "pythonservice.exe" or "civiccast" in text or name.startswith("gst-worker"):
            roots.add(p.get("ProcessId"))
    keep = set(roots)
    changed = True
    while changed:
        changed = False
        for p in data:
            if p.get("ProcessId") not in keep and p.get("ParentProcessId") in keep:
                keep.add(p.get("ProcessId")); changed = True
    rows = []
    for pid in sorted(keep):
        p = by_pid.get(pid)
        if not p:
            continue
        name = (p.get("Name") or "").lower()
        if not (name.startswith("gst-worker") or name.startswith("python") or name.startswith("gst-launch") or name == "pythonservice.exe" or name.startswith("ffmpeg")):
            continue
        rows.append({"name": p.get("Name"), "pid": pid, "rss_mb": round((p.get("WorkingSetSize") or 0) / 1048576, 1), "cmd": (p.get("CommandLine") or "")[:160]})
    return rows

# ---------------------------------------------------------------- UDP feed watch
class UdpWatch(threading.Thread):
    """Bind the channel's UDP destination and measure packet arrival gaps (freeze proxy) and bitrate."""
    def __init__(self, channel, port):
        super().__init__(daemon=True)
        self.channel, self.port = channel, port
        self.lock = threading.Lock()
        self.reset()
        self.bound = False
        self.last_pkt = None
        self.total_pkts = 0
    def reset(self):
        self.pkts = 0; self.bytes = 0; self.max_gap = 0.0; self.gaps_over = []
    def run(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", self.port)); self.bound = True
        except Exception as e:
            log(f"[{self.channel}] UDP bind {self.port} failed: {e}"); return
        s.settimeout(1.0)
        while not os.path.exists(STOP_PATH):
            try:
                data, _ = s.recvfrom(65536)
            except socket.timeout:
                continue
            except Exception as e:
                log(f"[{self.channel}] UDP recv error: {e}"); time.sleep(1); continue
            t = time.time()
            with self.lock:
                if self.last_pkt is not None:
                    gap = t - self.last_pkt
                    if gap > self.max_gap:
                        self.max_gap = gap
                    if gap > FREEZE_SECONDS:
                        self.gaps_over.append((t, round(gap, 1)))
                self.last_pkt = t
                self.pkts += 1; self.total_pkts += 1; self.bytes += len(data)
    def snapshot(self, reset=True):
        with self.lock:
            silent = (time.time() - self.last_pkt) if self.last_pkt else None
            snap = {"pkts": self.pkts, "kbps": round(self.bytes * 8 / 1000 / 60, 1), "max_gap_s": round(self.max_gap, 2), "gaps_over_5s": list(self.gaps_over), "silent_for_s": round(silent, 1) if silent is not None else None, "bound": self.bound}
            if reset:
                self.reset()
            return snap

# ---------------------------------------------------------------- channel snapshot
def channel_snapshot(ch):
    st_status, state = api(f"/api/staff/egress/channels/{ch}/state")
    h_status, health = api(f"/api/staff/egress/channels/{ch}/health?limit=1")
    raw = {"state": state, "health": health, "http": [st_status, h_status]}
    hs = health[0] if isinstance(health, list) and health else {}
    sd = state if isinstance(state, dict) else {}
    row = {
        "state": sd.get("state"),
        "pid": sd.get("pid"),
        "source_label": sd.get("current_source_label"),
        "seconds_on_air": hs.get("seconds_on_air"),
        "dropped_frames": hs.get("dropped_frames"),
        "captions_state": hs.get("caption_status"),
        "last_error": sd.get("last_error"),
        "sink_connected": json.dumps(hs.get("sink_connected")) if hs.get("sink_connected") is not None else None,
        "encoder_fps": hs.get("encoder_fps"),
        "encoder_kbps": hs.get("encoder_bitrate_kbps"),
        "health_sampled_at": hs.get("sampled_at"),
    }
    return row, raw

def main():
    if not TOKEN:
        print("no CIVICCAST_STAFF_TOKEN in environment", flush=True); sys.exit(2)
    start = time.time()
    event(f"sampler started; soak window {SOAK_HOURS} h; channels {list(CHANNELS)}; UDP ports {list(CHANNELS.values())}")
    watches = {ch: UdpWatch(ch, port) for ch, port in CHANNELS.items()}
    for w in watches.values():
        w.start()
    new_csv = not os.path.exists(CSV_PATH)
    csvf = open(CSV_PATH, "a", newline="", encoding="utf-8")
    w = csv.writer(csvf)
    if new_csv:
        w.writerow(["time", "channel", "state", "pid", "source_label", "seconds_on_air", "dropped_frames", "captions_state", "rss_mb_by_process", "readiness_banner", "alerts_firing", "sink_connected", "encoder_fps", "encoder_kbps", "last_error", "udp_kbps_last_min", "udp_max_gap_s_last_5min"])
        csvf.flush()
    prev = {ch: {} for ch in CHANNELS}
    last_label = {ch: None for ch in CHANNELS}
    last_state = {ch: None for ch in CHANNELS}
    last_pid = {ch: None for ch in CHANNELS}
    label_changes = {ch: [] for ch in CHANNELS}
    rss_hist = {}
    known_alerts = set()
    next_sample = start
    next_state = start
    next_udp_log = start + 60
    udp_5min = {ch: {"max_gap": 0.0, "kbps": []} for ch in CHANNELS}
    boundary_checked = set()
    while True:
        if os.path.exists(STOP_PATH):
            event("SOAK-STOP found; sampler exiting"); break
        if time.time() - start > SOAK_HOURS * 3600:
            event(f"soak window of {SOAK_HOURS} h elapsed; sampler exiting"); break
        t = time.time()
        # ---- 5-second state polling: program changes, state changes, relaunches, errors
        if t >= next_state:
            next_state = t + STATE_EVERY
            for ch in CHANNELS:
                status, sd = api(f"/api/staff/egress/channels/{ch}/state", timeout=8)
                if not isinstance(sd, dict):
                    continue
                label = sd.get("current_source_label"); state = sd.get("state"); pid = sd.get("pid"); err = sd.get("last_error")
                if label != last_label[ch]:
                    if last_label[ch] is not None:
                        label_changes[ch].append((time.time(), last_label[ch], label))
                        event(f"[{ch}] program change: {last_label[ch]!r} -> {label!r}")
                    last_label[ch] = label
                if state != last_state[ch]:
                    if last_state[ch] is not None:
                        event(f"[{ch}] STATE {last_state[ch]} -> {state}" + (f" (last_error={err!r})" if err else ""))
                    last_state[ch] = state
                if pid != last_pid[ch]:
                    if last_pid[ch] is not None and pid is not None:
                        event(f"[{ch}] RELAUNCH pid {last_pid[ch]} -> {pid}")
                    last_pid[ch] = pid
                if err and err != prev[ch].get("_err_seen"):
                    event(f"[{ch}] last_error: {err!r}")
                    prev[ch]["_err_seen"] = err
            n = now()
            if n.minute % 5 == 0 and 35 <= n.second < 41:
                key = n.strftime("%H:%M")
                if key not in boundary_checked and time.time() - start > 120:
                    boundary_checked.add(key)
                    boundary = n.replace(second=0, microsecond=0).timestamp()
                    for ch in CHANNELS:
                        hit = [c for c in label_changes[ch] if abs(c[0] - boundary) <= 30]
                        if not hit:
                            event(f"[{ch}] MISSED program change at {key}: source label stayed {last_label[ch]!r} (no change within 30 s of the boundary)")
        # ---- per-minute UDP log
        if t >= next_udp_log:
            next_udp_log = t + 60
            parts = []
            for ch, wch in watches.items():
                s = wch.snapshot()
                udp_5min[ch]["max_gap"] = max(udp_5min[ch]["max_gap"], s["max_gap_s"])
                udp_5min[ch]["kbps"].append(s["kbps"])
                parts.append(f"{ch}: {s['kbps']} kbps, {s['pkts']} pkts, max gap {s['max_gap_s']} s" + (f", silent {s['silent_for_s']} s" if s['silent_for_s'] and s['silent_for_s'] > 2 else "") + ("" if s["bound"] else " (NOT BOUND)"))
                for gt, gap in s["gaps_over_5s"]:
                    event(f"[{ch}] FREEZE? UDP feed silent for {gap} s ending {datetime.datetime.fromtimestamp(gt).strftime('%H:%M:%S')}")
                if s["bound"] and s["pkts"] == 0 and last_state[ch] in ON_AIR_STATES:
                    event(f"[{ch}] UDP feed: no packets in the last minute while state is {last_state[ch]}")
            with open(UDP_LOG, "a", encoding="utf-8") as f:
                f.write(f"{ts()} " + " | ".join(parts) + "\n")
        # ---- 5-minute CSV sample
        if t >= next_sample:
            next_sample = t + SAMPLE_EVERY
            procs = processes()
            rss_str = "|".join(f"{p['name']}:{p['pid']}={p['rss_mb']}" for p in procs)
            for p in procs:
                rss_hist.setdefault(p["pid"], []).append(p["rss_mb"])
                h = rss_hist[p["pid"]][-12:]
                if len(h) == 12 and all(h[i] <= h[i+1] for i in range(11)) and h[-1] - h[0] >= max(20, 0.10 * h[0]):
                    event(f"RSS growing steadily: {p['name']} pid {p['pid']} {h[0]} -> {h[-1]} MB over the last hour")
            r_status, readiness = api("/api/staff/station-box-profile/readiness")
            banner = ""
            if isinstance(readiness, dict):
                bad = [d.get("label") + "=" + d.get("color") for d in readiness.get("dimensions", []) if d.get("color") not in ("green", None)]
                banner = f"{readiness.get('overall')}:" + ",".join(bad)
            a_status, alerts = api("/api/staff/alert-events?state=firing&limit=50")
            alist = alerts if isinstance(alerts, list) else (alerts.get("items", []) if isinstance(alerts, dict) else [])
            alert_titles = []
            for a in alist:
                aid = a.get("alert_id") or a.get("id") or json.dumps(a)[:60]
                title = a.get("title") or a.get("rule_id") or aid
                alert_titles.append(str(title))
                if aid not in known_alerts:
                    known_alerts.add(aid); event(f"ALERT firing: {title}")
            for ch in CHANNELS:
                row, raw = channel_snapshot(ch)
                with open(RAW_PATH, "a", encoding="utf-8") as rf:
                    rf.write(json.dumps({"t": ts(), "channel": ch, "raw": raw, "procs": procs}, default=str) + "\n")
                u = udp_5min[ch]; kb = u["kbps"][-1] if u["kbps"] else None
                w.writerow([ts(), ch, row["state"], row["pid"], row["source_label"], row["seconds_on_air"], row["dropped_frames"], row["captions_state"], rss_str, banner, ";".join(alert_titles), row["sink_connected"], row["encoder_fps"], row["encoder_kbps"], row["last_error"], kb, u["max_gap"]])
                csvf.flush()
                udp_5min[ch] = {"max_gap": 0.0, "kbps": []}
                p = prev[ch]
                if row["state"] and row["state"] not in ON_AIR_STATES:
                    event(f"[{ch}] state is {row['state']!r} (not on air) at sample time")
                try:
                    if p.get("dropped_frames") is not None and row["dropped_frames"] is not None and float(row["dropped_frames"]) > float(p["dropped_frames"]):
                        event(f"[{ch}] dropped frames rose {p['dropped_frames']} -> {row['dropped_frames']}")
                except Exception:
                    pass
                p.update(row); prev[ch] = p
            if banner and not banner.startswith("green"):
                if banner != prev.get("_banner"):
                    event(f"readiness banner: {banner}")
                    prev["_banner"] = banner
        time.sleep(1)
    csvf.close()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log(f"FATAL {e!r}")
        event(f"sampler crashed: {e!r}")
        raise

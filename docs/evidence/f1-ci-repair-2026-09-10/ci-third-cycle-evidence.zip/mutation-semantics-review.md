# Independent mutation result semantics review

Reviewer: Sol agent /root/ci_review (gpt-5.6-sol), read-only; no tests, edits or reruns.
Scope: .github/workflows/deterministic-detectors.yml at 8653b56f.

A green nonempty-scope job requires mutmut run and mutmut results exit zero,
a nonempty results.log, and no not-checked entries. It does not enforce zero
survivors, a minimum score, or whole-repository mutation quality. Quote the
selected changed non-test Python files and actual category counts; do not
invent a score. An empty-scope green skip supplies no mutation proof.

A failed stats/baseline run supplies no mutation results. A whole-job timeout
at the 120-minute cap leaves an incomplete campaign; partial killed/survived
counts do not constitute a complete result set or score. A per-mutant timeout
category inside a complete report is distinct from the entire job timing out.

A successful baseline in the instrumented copy supports that the included
state-guard regression no longer breaks the baseline. The guard test is not
ignored or deselected. Passing cases are silent under pytest -q, so this is
baseline-level support, not a named per-node receipt or proof that the guard
ran against every mutant (test selection and -x apply).

Workflow references: job timeout lines141-149; diff scope176-210; configured
runner263-266; selection388; run/results/completeness gates394-411.

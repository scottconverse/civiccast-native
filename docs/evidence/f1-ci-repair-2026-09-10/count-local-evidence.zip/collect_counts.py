"""Capture actual native inventories using the policy's subprocess helper."""
import json
import sys
from pathlib import Path

root = Path.cwd()
sys.path.insert(0, str(root))
from tests.policy.test_native_caption_workflow_policy import _collect_native_tests

counts = {
    str(marker): _collect_native_tests(marker)
    for marker in ("not windows_only", None, "not integration")
}
print(json.dumps({"python": sys.executable, "counts": counts}, indent=2))
assert counts == {"not windows_only": 1823, "None": 2024, "not integration": 2021}
